"""Extract a plain-text transcript from a single YouTube video URL."""

from __future__ import annotations

import argparse
import html
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import parse_qs, urlparse


@dataclass(frozen=True)
class TranscriptResult:
    title: str
    transcript: str
    output_path: Path
    caption_source: str
    language: str
    caption_format: str


def _load_dependencies():
    try:
        import requests
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            "Missing dependency: requests. Run `python -m pip install -r requirements.txt`."
        ) from exc

    try:
        from yt_dlp import YoutubeDL
    except ImportError:
        try:
            from yt_dlp.YoutubeDL import YoutubeDL
        except ModuleNotFoundError as exc:
            raise ModuleNotFoundError(
                "Missing dependency: yt-dlp. Run `python -m pip install -r requirements.txt`."
            ) from exc

    return requests, YoutubeDL


def _validate_youtube_url(video_url: str) -> str:
    if not isinstance(video_url, str) or not video_url.strip():
        raise ValueError("video_url must be a non-empty string.")

    video_url = video_url.strip()
    host = (urlparse(video_url).hostname or "").lower()
    valid_hosts = {"youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be"}

    if host not in valid_hosts:
        raise ValueError("Please enter a valid youtube.com or youtu.be video URL.")

    return video_url


def extract_video_id(video_url: str) -> str:
    parsed = urlparse(_validate_youtube_url(video_url))
    host = (parsed.hostname or "").lower()

    if host == "youtu.be":
        video_id = parsed.path.strip("/").split("/", 1)[0]
    else:
        video_id = parse_qs(parsed.query).get("v", [""])[0]

    video_id = re.sub(r"[^A-Za-z0-9_-]", "", video_id)
    if not video_id:
        raise ValueError("Could not determine a video id from the URL.")

    return video_id


def _choose_caption_track(info: dict, language: str):
    subtitles = info.get("subtitles") or {}
    automatic = info.get("automatic_captions") or {}

    candidates = [language]
    if "-" in language:
        candidates.append(language.split("-", 1)[0])

    for tracks, source_name in (
        (subtitles, "human subtitles"),
        (automatic, "automatic captions"),
    ):
        for candidate in candidates:
            if tracks.get(candidate):
                return candidate, tracks[candidate], source_name

        prefix = language.split("-", 1)[0] + "-"
        matching_language = next((key for key in tracks if key.startswith(prefix)), None)
        if matching_language:
            return matching_language, tracks[matching_language], source_name

    available = sorted(set(subtitles) | set(automatic))
    available_text = ", ".join(available) if available else "none"
    raise ValueError(
        f"No captions found for language {language!r}. Available languages: {available_text}"
    )


def _choose_supported_format(tracks: list[dict]):
    for extension in ("json3", "vtt"):
        match = next(
            (item for item in tracks if item.get("ext") == extension and item.get("url")),
            None,
        )
        if match:
            return extension, match["url"]

    raise ValueError("Captions were found, but neither JSON3 nor VTT format is available.")


def _parse_json3(payload: str) -> list[str]:
    data = json.loads(payload)
    lines = []

    for event in data.get("events", []):
        segments = event.get("segs") or []
        text = "".join(segment.get("utf8", "") for segment in segments)
        text = html.unescape(text).replace("\n", " ").strip()
        if text:
            lines.append(text)

    return lines


def _parse_vtt(payload: str) -> list[str]:
    lines = []
    timestamp = re.compile(
        r"^(?:\d{2}:)?\d{2}:\d{2}\.\d{3}\s+-->\s+(?:\d{2}:)?\d{2}:\d{2}\.\d{3}"
    )
    in_cue = False

    for raw_line in payload.splitlines():
        line = raw_line.strip()

        if timestamp.match(line):
            in_cue = True
            continue

        if not line:
            in_cue = False
            continue

        if in_cue:
            line = re.sub(r"<[^>]+>", "", line)
            line = html.unescape(line).strip()
            if line:
                lines.append(line)

    return lines


def _remove_adjacent_duplicates(lines: list[str]) -> list[str]:
    cleaned = []
    for line in lines:
        normalised = re.sub(r"\s+", " ", line).strip()
        if normalised and (not cleaned or normalised != cleaned[-1]):
            cleaned.append(normalised)
    return cleaned


def extract_transcript(video_url: str, language: str = "en") -> tuple[str, dict]:
    """Return plain transcript text and metadata for one YouTube video."""
    requests, YoutubeDL = _load_dependencies()
    video_url = _validate_youtube_url(video_url)

    options = {
        "skip_download": True,
        "quiet": True,
        "no_warnings": True,
    }

    with YoutubeDL(options) as downloader:
        info = downloader.extract_info(video_url, download=False)

    selected_language, tracks, source_name = _choose_caption_track(info, language)
    caption_format, caption_url = _choose_supported_format(tracks)

    response = requests.get(
        caption_url,
        timeout=30,
        headers={"User-Agent": "Mozilla/5.0"},
    )
    response.raise_for_status()

    if not response.text.strip():
        raise ValueError("YouTube returned an empty caption file.")

    if caption_format == "json3":
        lines = _parse_json3(response.text)
    else:
        lines = _parse_vtt(response.text)

    lines = _remove_adjacent_duplicates(lines)
    transcript = re.sub(r"\s+", " ", " ".join(lines)).strip()

    if not transcript:
        raise ValueError("Captions were downloaded, but no transcript text could be parsed.")

    metadata = {
        "title": info.get("title") or "Untitled video",
        "caption_source": source_name,
        "language": selected_language,
        "caption_format": caption_format,
    }
    return transcript, metadata


def save_transcript(
    video_url: str,
    language: str = "en",
    output_dir: str | Path = "transcripts",
) -> TranscriptResult:
    transcript, metadata = extract_transcript(video_url, language=language)
    output_path = Path(output_dir) / f"{extract_video_id(video_url)}_transcript.txt"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(transcript, encoding="utf-8")

    return TranscriptResult(
        title=metadata["title"],
        transcript=transcript,
        output_path=output_path,
        caption_source=metadata["caption_source"],
        language=metadata["language"],
        caption_format=metadata["caption_format"],
    )


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extract a plain-text transcript from one YouTube video URL."
    )
    parser.add_argument("url", help="YouTube video URL")
    parser.add_argument(
        "-l",
        "--language",
        default="en",
        help="Preferred caption language, default: en",
    )
    parser.add_argument(
        "-o",
        "--output-dir",
        default="transcripts",
        help="Directory for saved transcript text, default: transcripts",
    )
    parser.add_argument(
        "--print-transcript",
        action="store_true",
        help="Print the transcript text after saving it.",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv or sys.argv[1:])

    try:
        result = save_transcript(
            args.url,
            language=args.language,
            output_dir=args.output_dir,
        )
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    print(f"Title: {result.title}")
    print(
        "Caption source: "
        f"{result.caption_source} ({result.language}, {result.caption_format})"
    )
    print(f"Transcript length: {len(result.transcript):,} characters")
    print(f"Saved transcript: {result.output_path.resolve()}")

    if args.print_transcript:
        print("\n--- TRANSCRIPT TEXT ---\n")
        print(result.transcript)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
