"""Download plain-text transcripts for every video in a YouTube playlist."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

from extract_transcript import save_transcript
from yt_dlp import YoutubeDL


def write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    temporary.replace(path)


def playlist_entries(playlist_url: str) -> tuple[str, list[dict]]:
    options = {
        "extract_flat": True,
        "skip_download": True,
        "quiet": True,
        "no_warnings": True,
    }
    with YoutubeDL(options) as downloader:
        info = downloader.extract_info(playlist_url, download=False)

    entries = []
    for position, entry in enumerate(info.get("entries") or [], start=1):
        if not entry:
            continue
        video_id = entry.get("id")
        if not video_id:
            continue
        entries.append(
            {
                "position": position,
                "video_id": video_id,
                "url": f"https://www.youtube.com/watch?v={video_id}",
                "official_title": entry.get("title") or "",
                "status": "pending",
            }
        )
    return info.get("title") or "", entries


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("playlist_url")
    parser.add_argument("--output-dir", default="transcripts")
    parser.add_argument("--manifest", default="transcript_download_manifest.json")
    parser.add_argument("--delay", type=float, default=2.0)
    parser.add_argument("--attempts", type=int, default=3)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    output_dir = Path(args.output_dir)
    manifest_path = Path(args.manifest)
    output_dir.mkdir(parents=True, exist_ok=True)

    playlist_title, entries = playlist_entries(args.playlist_url)
    manifest = {
        "playlist_url": args.playlist_url,
        "playlist_title": playlist_title,
        "playlist_count": len(entries),
        "completed": 0,
        "failed": 0,
        "entries": entries,
    }
    write_json(manifest_path, manifest)
    print(f"Playlist: {playlist_title}", flush=True)
    print(f"Entries: {len(entries)}", flush=True)

    retry_waits = (10, 30, 60)
    for entry in entries:
        position = entry["position"]
        video_id = entry["video_id"]
        output_path = output_dir / f"{video_id}_transcript.txt"

        if output_path.exists() and output_path.stat().st_size > 0:
            entry["status"] = "existing"
            entry["transcript"] = str(output_path)
            manifest["completed"] += 1
            print(f"[{position}/{len(entries)}] EXISTS {video_id}", flush=True)
            write_json(manifest_path, manifest)
            continue

        last_error = ""
        for attempt in range(1, args.attempts + 1):
            try:
                result = save_transcript(
                    entry["url"],
                    language="en-orig",
                    output_dir=output_dir,
                )
                entry["status"] = "complete"
                entry["official_title"] = result.title
                entry["transcript"] = str(result.output_path)
                entry["caption_source"] = result.caption_source
                entry["caption_language"] = result.language
                entry["caption_format"] = result.caption_format
                manifest["completed"] += 1
                print(
                    f"[{position}/{len(entries)}] OK {video_id} "
                    f"({result.language}, {len(result.transcript):,} chars)",
                    flush=True,
                )
                break
            except Exception as exc:  # Continue so one unavailable video cannot stop the batch.
                last_error = str(exc)
                if attempt < args.attempts:
                    wait_seconds = retry_waits[min(attempt - 1, len(retry_waits) - 1)]
                    print(
                        f"[{position}/{len(entries)}] RETRY {video_id} "
                        f"in {wait_seconds}s: {last_error}",
                        flush=True,
                    )
                    time.sleep(wait_seconds)
                else:
                    entry["status"] = "failed"
                    entry["error"] = last_error
                    manifest["failed"] += 1
                    print(
                        f"[{position}/{len(entries)}] FAILED {video_id}: {last_error}",
                        flush=True,
                    )

        write_json(manifest_path, manifest)
        if args.delay > 0:
            time.sleep(args.delay)

    print(
        f"Finished: {manifest['completed']} completed, {manifest['failed']} failed",
        flush=True,
    )
    return 0 if manifest["failed"] == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
