# Dan John playlist V1.1

This dataset is produced directly by Codex from the downloaded transcripts. It does not use an API or a local language model.

Each completed record contains:

- playlist position;
- video ID;
- canonical YouTube URL;
- official title;
- transcript reference;
- meaningful objects;
- meaningful transcript-supported relations.

It does not contain an alternative title, summary, or semantic map.

## Directories

- `records/`: one JSON record per completed video
- `progress.json`: corpus completion status

## Evidence standard

Objects are meaningful identifiable things in the transcript, not every noun. Relations must be explicitly stated or strongly supported by the transcript. Attribution, conditions, and qualifications are preserved when they materially affect a relation. Mention or proximity alone does not establish a substantive relation.

